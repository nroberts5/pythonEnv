For users of pydicom < 1.0
========================

.. rubric:: Warning about pydicom < 1.0 and reference to Transition to Pydicom 1 section

Pydicom < 1
-------

.. warning::

        Pydicom versions 1.0 and higher introduce backwards-incompatible changes.
        If you have used earlier versions of pydicom, see :doc:`transition_to_pydicom1` for details.
