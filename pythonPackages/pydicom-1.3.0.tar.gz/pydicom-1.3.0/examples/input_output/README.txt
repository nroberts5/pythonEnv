.. _input_ouput_examples:

Input-output
------------

These examples illustrate the use of pydicom to read DICOM data.
