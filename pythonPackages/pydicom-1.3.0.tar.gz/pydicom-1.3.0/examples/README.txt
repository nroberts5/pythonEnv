.. _general_examples:

General examples
----------------

Somewhere to start
